###############################################################################
setwd("C:/Users/dopheidea/OneDrive - MWLR/Documents/")
Fungi_df <- read.table("Fungi_df2.txt", sep = "\t", header = TRUE, check.names = FALSE)
head(Fungi_df)

# Reorganise data into OTU ID, (sample 1, sample 2 ... ), taxonomy columns.
get_fg_tx <- function(x){
  OTU_ID <- x[["OTU"]]
  x[["Species"]] <- gsub("\\.", "", x[["Species"]])
  x[["Species"]] <- gsub(" ", "_", x[["Species"]])
  tx <- paste0(x[["Species"]], "|p__", x[["Phylum"]],";c__", x[["Class"]],";o__", x[["Order"]],
               ";f__", x[["Family"]],";g__", x[["Genus"]],";s__", x[["Species"]])
  tx_fg <- c(as.character(OTU_ID), tx)
}

OTUs <- unique(Fungi_df$OTU)
Fungi_fg_out <- data.frame(matrix(nrow = length(OTUs), ncol = 2))
colnames(Fungi_fg_out) <- c("OTU ID", "taxonomy")
Fungi_fg_out$`OTU ID` <- OTUs
for(OTU in Fungi_fg_out$`OTU ID`){
  tx_rows <- Fungi_df[Fungi_df$OTU == OTU, ]
  tx_fg <- get_fg_tx(x = tx_rows[1, ])
  Fungi_fg_out$taxonomy[Fungi_fg_out$`OTU ID` == OTU] <- tx_fg[[2]]
}

head(Fungi_fg_out)
write.table(Fungi_fg_out, "Fungi_OTUs.txt", sep = "\t", quote = FALSE, row.names = FALSE)
# Then: 
# C:
# cd Users/dopheidea/OneDrive - MWLR/Documents/Bioinformatics and code/Python Scripts
# python Guilds_v1.1.py -otu "C:/Users/dopheidea/OneDrive - MWLR/Documents/Fungi_OTUs_fg.txt" -db fungi

guilds <- read.table("Fungi_OTUs.guilds.txt", sep = "\t", header = TRUE, check.names = FALSE)
colnames(guilds)
colnames(guilds)[[1]] <- "OTU"
head(Fungi_df)
Fungi_df_guilds <- Fungi_df[, c(1:14)]
Fungi_df_guilds <- merge(Fungi_df_guilds, guilds, by = "OTU", all = TRUE)
Fungi_df_guilds <- Fungi_df_guilds[order]
write.table(Fungi_df_guilds, "Fungi_df2_guilds.txt", sep = "\t", quote = FALSE, row.names = FALSE)
